package com.github.joelgodofwar.mmh.version;

import java.lang.reflect.Method;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Bee;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Panda;
import org.bukkit.entity.Panda.Gene;
import org.bukkit.entity.Wolf;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import com.github.joelgodofwar.mmh.VersionWrapper;


public final class Wrapper_1_21_R5 implements VersionWrapper {
	public final static Logger logger = Logger.getLogger("MoreMobHeadsLib");
	private static final String CRAFTBUKKIT_PACKAGE = Bukkit.getServer().getClass().getPackage().getName();

	@Override
	public String getName(String name, Entity entity) {
		String strvariant = "";
		int colonIndex;
		switch (name) {
		case "WOLF":
			Class<?> craftWolfClass;
			try {
				craftWolfClass = Class.forName(cbClass("entity.CraftChicken"));
				Object craftWolf = craftWolfClass.cast(entity);
				Method getVariantMethod = craftWolfClass.getMethod("getVariant");
				Object wolfVar = getVariantMethod.invoke(craftWolf);
				strvariant = wolfVar.toString();
				colonIndex = strvariant.indexOf(":");
				String wolfType = (colonIndex != -1) ? strvariant.substring(colonIndex + 1).split(",")[0].trim().toUpperCase() : strvariant.split(",")[0].trim().toUpperCase();
				Wolf daWolf = (Wolf) entity;
				return daWolf.isAngry() ? "ANGRY_" + wolfType : wolfType;
			} catch (Exception e) {
				log(Level.WARNING, "Failed to get Wolf variant using reflection: " + e.getMessage());
				e.printStackTrace();
				return name;
			}
		case "CHICKEN":
			Class<?> craftChickenClass;
			try {
				craftChickenClass = Class.forName(cbClass("entity.CraftChicken"));
				Object craftChicken = craftChickenClass.cast(entity);
				Method getVariantMethod = craftChickenClass.getMethod("getVariant");
				Object chickenVar = getVariantMethod.invoke(craftChicken);
				strvariant = chickenVar.toString();
				colonIndex = strvariant.indexOf(":");
				String chickenType = (colonIndex != -1) ? strvariant.substring(colonIndex + 1).split(",")[0].trim().toUpperCase() : strvariant.split(",")[0].trim().toUpperCase();
				return chickenType;
			} catch (Exception e) {
				log(Level.WARNING, "Failed to get Chicken variant using reflection: " + e.getMessage());
				e.printStackTrace();
				return name;
			}
		case "COW":
			Class<?> craftCowClass;
			try {
				craftCowClass = Class.forName( cbClass( "entity.CraftCow" ) );
				Object craftCow = craftCowClass.cast( entity );
				Method getVariantMethod = craftCowClass.getMethod( "getVariant" );
				Object cowVar = getVariantMethod.invoke( craftCow );
				strvariant = cowVar.toString();
				colonIndex = strvariant.indexOf(":");
				String cowType = (colonIndex != -1) ? strvariant.substring(colonIndex + 1).split(",")[0].trim().toUpperCase() : strvariant.split(",")[0].trim().toUpperCase();
				return cowType;
			} catch (Exception e) {
				log(Level.WARNING, "Failed to get Cow variant using reflection: " + e.getMessage());
				e.printStackTrace();
				return name;
			}
		case "PIG":
			Class<?> craftPigClass;
			try {
				craftPigClass = Class.forName(cbClass("entity.CraftPig"));
				Object craftPig = craftPigClass.cast(entity);
				Method getVariantMethod = craftPigClass.getMethod("getVariant");
				Object pigVar = getVariantMethod.invoke(craftPig);
				strvariant = pigVar.toString();
				colonIndex = strvariant.indexOf(":");
				String pigType = (colonIndex != -1) ? strvariant.substring(colonIndex + 1).split(",")[0].trim().toUpperCase() : strvariant.split(",")[0].trim().toUpperCase();
				return pigType;
			} catch (Exception e) {
				log(Level.WARNING, "Failed to get Pig variant using reflection: " + e.getMessage());
				e.printStackTrace();
				return name;
			}
		default:
			return null;
		}
	}

	public static String cbClass(String className) {
		return CRAFTBUKKIT_PACKAGE + "." + className;
	}

	@Override public ItemStack addSound(ItemStack item, Entity entity) {
		EntityType eType = entity.getType();
		SkullMeta meta = (SkullMeta) item.getItemMeta();
		String name = eType.name();
		String soundType = "ambient";
		switch (eType) {
		case WOLF:
			Wolf wolf = (Wolf) entity;
			if(wolf.isAngry()) {
				soundType = "growl";
			}
			break;
		case TURTLE:
			soundType = "ambient_land";
			break;
		case SLIME:
			soundType = "squish_small";
			break;
		case PANDA:
			Panda panda = (Panda) entity;
			Gene gene = panda.getMainGene();
			switch (gene) {
			case WORRIED:
				soundType = "worried_ambient";
				break;
			case AGGRESSIVE:
				soundType = "aggressive_ambient";
				break;
			case WEAK:
				soundType = "sneeze";
				break;
			default:
				soundType = "ambient";
				break;
			}
			break;
		case MOOSHROOM:
			name = "COW";
			soundType = "ambient";
			break;
		case MAGMA_CUBE:
			soundType = "squish";
			break;
		case IRON_GOLEM:
		case PLAYER:
		case SNOW_GOLEM:
			soundType = "hurt";
			break;
		case CREEPER:
			soundType = "primed";
			break;
		case BEE:
			Bee daBee = (Bee) entity;
			int daAnger = daBee.getAnger();
			boolean daNectar = daBee.hasNectar();
			if((daAnger >= 1)&&(daNectar == true)){
				soundType = "loop_aggressive";
			}else if((daAnger >= 1)&&(daNectar == false)){
				soundType = "loop_aggressive";
			}else if((daAnger == 0)&&(daNectar == true)){
				soundType = "pollinate";
			}else if((daAnger == 0)&&(daNectar == false)){
				soundType = "loop";
			}
			break;
		case AXOLOTL:
			soundType = "idle_air";
			break;
		case SNIFFER:
			soundType = "scenting";
			break;
		case ALLAY:
			soundType = "ambient_without_item";
			break;
		case SPIDER:
		case CAVE_SPIDER:
			name = "SPIDER";
			soundType = "step";
			break;
		case COD:
		case SALMON:
		case TROPICAL_FISH:
		case TADPOLE:
			soundType = "flop";
			break;
		case PUFFERFISH:
			soundType = "blow_up";
			break;
		case TRADER_LLAMA:
			name = "LLAMA";
			soundType = "ambient";
			break;
		case WITHER:
			ItemMeta itemMeta = item.getItemMeta();
			String displayName = itemMeta.getDisplayName();
			if (displayName.contains("projectile")) {
				soundType = "shoot";
			} else {
				soundType = "ambient";
			}
			break;
		case BREEZE:
			soundType = "idle_ground";
			break;
		default:
			soundType = "ambient";
			break;
		}
		meta.setNoteBlockSound( NamespacedKey.minecraft( "entity." + name.toLowerCase() + "." + soundType ) );
		item.setItemMeta(meta);
		return item;
	}

	@Override public ItemStack addSound(ItemStack item, EntityType eType) {
		//EntityType eType = entity.getType();
		SkullMeta meta = (SkullMeta) item.getItemMeta();
		String name = eType.name();
		String soundType = "ambient";
		switch (eType) {
		case TURTLE:
			soundType = "ambient_land";
			break;
		case SLIME:
			soundType = "squish_small";
			break;
		case MOOSHROOM:
			name = "COW";
			soundType = "ambient";
			break;
		case MAGMA_CUBE:
			soundType = "squish";
			break;
		case IRON_GOLEM:
		case PLAYER:
		case SNOW_GOLEM:
			soundType = "hurt";
			break;
		case CREEPER:
			soundType = "primed";
			break;
		case BEE:
			soundType = "loop";
			break;
		case AXOLOTL:
			soundType = "idle_air";
			break;
		case SNIFFER:
			soundType = "scenting";
			break;
		case ALLAY:
			soundType = "ambient_without_item";
			break;
		case SPIDER:
		case CAVE_SPIDER:
			name = "SPIDER";
			soundType = "step";
			break;
		case COD:
		case SALMON:
		case TROPICAL_FISH:
		case TADPOLE:
			soundType = "flop";
			break;
		case PUFFERFISH:
			soundType = "blow_up";
			break;
		case TRADER_LLAMA:
			name = "LLAMA";
			soundType = "ambient";
			break;
		case WITHER:
			ItemMeta itemMeta = item.getItemMeta();
			String displayName = itemMeta.getDisplayName();
			if (displayName.contains("projectile")) {
				soundType = "shoot";
			} else {
				soundType = "ambient";
			}
			break;
		case BREEZE:
			soundType = "idle_ground";
			break;
		default:
			soundType = "ambient";
			break;
		}
		meta.setNoteBlockSound( NamespacedKey.minecraft( "entity." + name.toLowerCase() + "." + soundType ) );
		item.setItemMeta(meta);
		return item;
	}


	@Override public ItemStack getVanilla(EntityType eType) {
		//EntityType eType = entity.getType();
		Material material = null;
		switch(eType) {
		case CREEPER:
			material = Material.CREEPER_HEAD;
			break;
		case ENDER_DRAGON:
			material = Material.DRAGON_HEAD;
			break;
		case PIGLIN:
			material = Material.PIGLIN_HEAD;
			break;
		case SKELETON:
			material = Material.SKELETON_SKULL;
			break;
		case WITHER_SKELETON:
			material = Material.WITHER_SKELETON_SKULL;
			break;
		case ZOMBIE:
			material = Material.ZOMBIE_HEAD;
			break;
		default:

			break;
		}
		return new ItemStack(material);
	}

	public void log(String string) {
		log(Level.INFO, string);
	}

	public	void log(Level level, String dalog){// TODO: log
		logger.log(level, ChatColor.YELLOW + "MoreMobHeadsLib v" + ChatColor.RESET + " " + dalog );
	}

}