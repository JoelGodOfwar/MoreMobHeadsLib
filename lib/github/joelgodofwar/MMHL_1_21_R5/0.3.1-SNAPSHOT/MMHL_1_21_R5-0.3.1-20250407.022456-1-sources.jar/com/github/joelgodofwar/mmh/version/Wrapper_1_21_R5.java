package com.github.joelgodofwar.mmh.version;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.bukkit.entity.Chicken;
import org.bukkit.entity.Cow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Pig;
import org.bukkit.entity.Wolf;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import com.github.joelgodofwar.mmh.VersionWrapper;

public final class Wrapper_1_21_R5 implements VersionWrapper {
	private static final Logger logger = Logger.getLogger("MoreMobHeadsLib");

	@Override
	public String getName(String name, Entity entity) {
		String strvariant;
		int colonIndex;
		switch (name) {
		case "ARMADILLO":
			return name;
		case "WOLF":
			Wolf daWolf = (Wolf) entity;
			org.bukkit.entity.Wolf.Variant wolfVar = daWolf.getVariant();
			String wolfType = wolfVar.toString().toUpperCase();
			boolean angry = daWolf.isAngry();
			if (angry) {
				return "ANGRY_" + wolfType;
			}
			return wolfType;
		case "CHICKEN":
			strvariant = ((Chicken) entity).getVariant().toString();
			colonIndex = strvariant.indexOf(":");
			String chickenType = (colonIndex != -1) ? strvariant.substring(colonIndex + 1).split(",")[0].trim().toUpperCase() : strvariant.split(",")[0].trim().toUpperCase();
			log(Level.WARNING, "chickenType=" + chickenType);
			return chickenType;
		case "COW":
			strvariant = ((Cow) entity).getVariant().toString();
			colonIndex = strvariant.indexOf(":");
			String cowType = (colonIndex != -1) ? strvariant.substring(colonIndex + 1).split(",")[0].trim().toUpperCase() : strvariant.split(",")[0].trim().toUpperCase();
			log(Level.WARNING, "cowType=" + cowType);
			return cowType;
		case "PIG":
			strvariant = ((Pig) entity).getVariant().toString();
			colonIndex = strvariant.indexOf(":");
			String pigType = (colonIndex != -1) ? strvariant.substring(colonIndex + 1).split(",")[0].trim().toUpperCase() : strvariant.split(",")[0].trim().toUpperCase();
			log(Level.WARNING, "pigType=" + pigType);
			return pigType;
		case "BREEZE":
		case "BOGGED":
			return name;
		default:
			return null;
		}
	}

	@Override
	public ItemStack addSound(ItemStack item, Entity entity) {
		// Stub: Not relevant for this task
		SkullMeta meta = (SkullMeta) item.getItemMeta();
		item.setItemMeta(meta);
		return item;
	}

	@Override
	public ItemStack addSound(ItemStack item, EntityType eType) {
		// Stub: Not relevant for this task
		SkullMeta meta = (SkullMeta) item.getItemMeta();
		item.setItemMeta(meta);
		return item;
	}

	@Override
	public ItemStack getVanilla(EntityType eType) {
		// Stub: Not relevant for this task
		return null;
	}

	public void log(String string) {
		log(Level.INFO, string);
	}

	public void log(Level level, String dalog) {
		logger.log(level, "MoreMobHeadsLib: " + dalog);
	}
}